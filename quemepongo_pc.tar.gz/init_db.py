from sqlalchemy import create_engine, Column, String, Integer, DateTime, JSON, ForeignKey, Boolean, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import datetime

# Conexión local a tu Postgres en Termux
DATABASE_URL = "postgresql://localhost/quemepongo_db"
engine = create_engine(DATABASE_URL)
Base = declarative_base()

# --- DEFINICIÓN DE TABLAS ---

class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(String, primary_key=True)
    email = Column(String, unique=True)
    preferencias_estilo = Column(JSON) # Ej: {"minimalista": 0.8}

class Prenda(Base):
    __tablename__ = "prendas"
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("usuarios.id"))
    categoria = Column(String) # Chomba, Pantalón, etc.
    color_hex = Column(String)
    formalidad = Column(Integer)
    ultima_vez_usado = Column(DateTime, default=datetime.datetime.utcnow)
    es_favorito = Column(Boolean, default=False)

class ModaVigente(Base):
    __tablename__ = "moda_vigente"
    id = Column(Integer, primary_key=True)
    estilo = Column(String)
    paleta_colores = Column(ARRAY(String))
    prendas_clave = Column(ARRAY(String))

class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True)
    prenda_id = Column(String, ForeignKey("prendas.id"))
    puntuacion = Column(Integer) # -1, 1, 5

# Crear todas las tablas en la base de datos
if __name__ == "__main__":
    Base.metadata.create_all(engine)
    print("✅ ¡Arquitectura de tablas creada exitosamente en quemepongo_db!")

